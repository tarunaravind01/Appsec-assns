package com.example.giftcardsite.api.model

class BuyCardInfo(val amount: Int)