package com.example.giftcardsite.api.model

class LoginInfo(val username: String, val password:String)