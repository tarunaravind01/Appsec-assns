from hashlib import sha256
import time

# same salt used in all passwords
salt = '000000000000000000000000000078d2'.encode('utf-8')

adminEx = '18821d89de11ab18488fdc0a01f1ddf4d290e198b0f80cd4974fc031dc2615a3'

with open('rockyou.txt', mode='r', encoding='ISO-8859-1') as f:
	i = 0
	start_time = time.time()
	for p in f:
		i += 1
		if i % 1000000 == 0:
			print(f"Tested {i} passwords in {time.time() - start_time:.2f} seconds")
			start_time = time.time()
			print(i)

		p = p[:-1]

		
		hasher = sha256()
		hasher.update(salt)
		hasher.update(p.encode('utf-8'))

		if hasher.hexdigest() == adminEx:
			print(p)
			break
		
