python3 manage.py shell -c 'import import_dbs'
